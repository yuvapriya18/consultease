# ConsultEase
A full-stack application for faculty to submit research project details and for admins to filter, view, and manage submissions. Built with React (frontend) and Node.js/Express (backend), with Google Sheets and Drive integration.
